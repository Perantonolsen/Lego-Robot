function [ Integral ] = NumInt(TimeVector, ErrorVector,Index)
    % Sett inn kode for numerisk integrasjon her.
end