function justfixit(brick)
    while brick.conn.handle.BytesAvailable 
        fread(brick.conn.handle,1);
    end
    disp('Minnet er nu t�mt. Hurra.');
end
