function [ FilteredErrorValue ] = FIR_filter(ErrorVector,FilterSize,Index)
    if Index > FilterSize
        % Sett inn kode for FIR-filter
    else 
        FilteredErrorValue = ErrorVector(Index);
    end
end