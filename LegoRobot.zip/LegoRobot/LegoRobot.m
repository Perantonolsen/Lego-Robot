%% Initialisering av robot-objektet
% Kj�r InitBT slik at objektet b finnes i "Workspace"

%% Initialisering av variabler
% Lukk gamle plot
% Slett gamle variabler utenom b
% Kj�r justfixit.m for � t�mme buffer
% Lag variabler som definerer f.eks 
%   - Hvor mange samplinger som skal lagres (Dette avhenger av hvor lenge
%   roboten kj�rer)
%   - Verdier/tuningvariabler for regulering: Kp, Ki og Kd. (Evt. Ti, Td)
%   - Utgangshastighet v_0 (hvor fort roboten skal kj�re normalt)
%   osv..


%% Kj�ring av roboten
% M�l f�rste gr�tone(dette vil v�re referansen din).
% Start tidtaking
% Start motorer og sett farten til utgangshastigheten

% while (kj�rebetingelse: Ingenting blokkerer avstandsm�leren)
%   - Ta gr�tonem�ling og lag tidsstempel
%   - Filtrer ut feilaktige gr�tonem�linger
%   - Finn avviket e(t) 
%   - Beregn p�draget basert p� e(t) 
%   - Juster motorenes fart med p�draget u(t)
% avslutt while

%% Avslutning
% Stopp motorene
% regn ut score p� gjennomkj�ringen
% plot resultatene og analyser


