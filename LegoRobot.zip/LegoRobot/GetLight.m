function [ LightValue ] = GetLight(brick)
    % Sett inn kode for � lese av gr�tone her.
end