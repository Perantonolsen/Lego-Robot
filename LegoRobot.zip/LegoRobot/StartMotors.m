function StartMotors(brick)
    % Sett in kode for � starte begge motorene her.
end