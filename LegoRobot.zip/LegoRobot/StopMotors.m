function StopMotors(brick)
    % Sett inn kode for � stoppe begge motorene her.
end