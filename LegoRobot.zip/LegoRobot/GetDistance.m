function [ Distance ] = GetDistance(brick)
    Distance = brick.inputReadSI(0, Device.Port4, Device.USDistCM); % Leser av avstandsm�ler fra Port4.
end