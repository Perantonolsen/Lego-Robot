%% Initialiseringsfil for bl�tann.
b = Brick('ioType', 'instrbt', 'btDevice', 'NAVN', 'btChannel', 1);
% Dersom objektet b av typen brick st�r oppf�rt i "Workspace" kan du
% fortsette med LegoRobot.m