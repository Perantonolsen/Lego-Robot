function [ Der ] = NumDer(TimeVector, FilteredErrorVector,Index)
    % Sett inn kode for numerisk derivasjon her.
end