function SetSpeed(brick, LeftVelocity, RightVelocity)
    % Sett inn kode for � sette farten til venstre og h�yre motor her.
end

