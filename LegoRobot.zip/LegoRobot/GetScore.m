function [Score] = GetScore(TimeVector, ErrorVector, Index)
    
    integral = 0;
    for i = 1:Index-1
       integral = integral + abs(ErrorVector(i))*(TimeVector(i+1)-TimeVector(i));
    end

    Score = integral/(TimeVector(Index)-TimeVector(1));
    
end