function PlayTone(brick, volume, frequency, duration)
    brick.playTone(volume, frequency, duration); % Brick plays a tone with given volume, frequency and duration.
end